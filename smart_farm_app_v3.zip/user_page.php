<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

// ---------- CSRF token ----------
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function flash($type, $msg, $tab) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg, 'tab' => $tab];
    header("Location: user_page.php#" . $tab);
    exit();
}

// ---------- Load current user ----------
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) { // account was removed
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

// ---------- Handle form submissions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        flash('error', 'Invalid request. Please try again.', 'overview');
    }

    // Update profile
    if (isset($_POST['update_profile'])) {
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Please enter a valid name and email.', 'profile');
        }

        $chk = $conn->prepare("SELECT id FROM users WHERE email = ? AND id <> ?");
        $chk->bind_param("si", $email, $user['id']);
        $chk->execute();
        $chk->store_result();
        if ($chk->num_rows > 0) {
            flash('error', 'That email is already in use.', 'profile');
        }

        $upd = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
        $upd->bind_param("ssi", $name, $email, $user['id']);
        $upd->execute();

        $_SESSION['name']  = $name;
        $_SESSION['email'] = $email;
        flash('success', 'Profile updated.', 'profile');
    }

    // Change password
    if (isset($_POST['change_password'])) {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $user['password'])) {
            flash('error', 'Current password is incorrect.', 'security');
        }
        if (strlen($new) < 8) {
            flash('error', 'New password must be at least 8 characters.', 'security');
        }
        if ($new !== $confirm) {
            flash('error', 'New passwords do not match.', 'security');
        }

        $hash = password_hash($new, PASSWORD_DEFAULT);
        $upd  = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->bind_param("si", $hash, $user['id']);
        $upd->execute();
        session_regenerate_id(true);
        flash('success', 'Password changed successfully.', 'security');
    }
}

// ---------- Prepare view data ----------
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$memberSince = !empty($user['created_at'])
    ? date('M j, Y', strtotime($user['created_at']))
    : '—';
$daysMember = !empty($user['created_at'])
    ? max(0, (int) floor((time() - strtotime($user['created_at'])) / 86400))
    : null;
$initial = strtoupper(mb_substr($user['name'], 0, 1));
$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<link rel="stylesheet" href="dashboard.css">
</head>
<body>

<header class="topbar">
  <div class="brand">My Account</div>
  <div class="topbar-right">
    <span class="avatar"><?= $h($initial) ?></span>
    <span class="topbar-name"><?= $h($user['name']) ?></span>
    <a class="btn-link" href="logout.php">Logout</a>
  </div>
</header>

<div class="layout">
  <nav class="sidebar">
    <a href="#overview" class="tab-link" data-tab="overview">Overview</a>
    <a href="#profile" class="tab-link" data-tab="profile">Profile</a>
    <a href="#security" class="tab-link" data-tab="security">Security</a>
    <a href="farm_dashboard.php" class="tab-link">Live farm data</a>
    <?php if ($user['role'] === 'admin'): ?>
      <a href="admin_page.php" class="tab-link admin-link">Admin page</a>
    <?php endif; ?>
  </nav>

  <main class="content">

    <?php if ($flash): ?>
      <div class="alert <?= $h($flash['type']) ?>"><?= $h($flash['msg']) ?></div>
    <?php endif; ?>

    <!-- Overview -->
    <section class="panel" id="overview">
      <h1>Welcome back, <?= $h($user['name']) ?> 👋</h1>
      <p class="muted">Here's a quick look at your account.</p>

      <div class="cards">
        <div class="card">
          <span class="card-label">Role</span>
          <span class="card-value"><?= $h(ucfirst($user['role'])) ?></span>
        </div>
        <div class="card">
          <span class="card-label">Member since</span>
          <span class="card-value"><?= $h($memberSince) ?></span>
        </div>
        <div class="card">
          <span class="card-label">Days with us</span>
          <span class="card-value"><?= $daysMember !== null ? $h($daysMember) : '—' ?></span>
        </div>
      </div>

      <div class="box">
        <h3>Account details</h3>
        <dl>
          <dt>Name</dt><dd><?= $h($user['name']) ?></dd>
          <dt>Email</dt><dd><?= $h($user['email']) ?></dd>
          <dt>Account ID</dt><dd>#<?= $h($user['id']) ?></dd>
        </dl>
      </div>
    </section>

    <!-- Profile -->
    <section class="panel" id="profile">
      <h1>Profile</h1>
      <p class="muted">Update your name and email address.</p>
      <form method="post" class="box">
        <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
        <label>Name
          <input type="text" name="name" value="<?= $h($user['name']) ?>" required>
        </label>
        <label>Email
          <input type="email" name="email" value="<?= $h($user['email']) ?>" required>
        </label>
        <button type="submit" name="update_profile">Save changes</button>
      </form>
    </section>

    <!-- Security -->
    <section class="panel" id="security">
      <h1>Security</h1>
      <p class="muted">Change your password. Use at least 8 characters.</p>
      <form method="post" class="box">
        <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
        <label>Current password
          <input type="password" name="current_password" required autocomplete="current-password">
        </label>
        <label>New password
          <input type="password" name="new_password" minlength="8" required autocomplete="new-password">
        </label>
        <label>Confirm new password
          <input type="password" name="confirm_password" minlength="8" required autocomplete="new-password">
        </label>
        <button type="submit" name="change_password">Update password</button>
      </form>
    </section>

  </main>
</div>

<script src="dashboard.js"></script>
</body>
</html>
