<?php
// Weather data from Open-Meteo (free, no API key). Cached for 30 minutes.

function farm_setting($conn, $name, $default = null) {
    $st = $conn->prepare("SELECT `value` FROM farm_settings WHERE name = ?");
    $st->bind_param("s", $name);
    $st->execute();
    $r = $st->get_result()->fetch_assoc();
    return $r ? $r['value'] : $default;
}

function farm_setting_set($conn, $name, $value) {
    $value = (string) $value;
    $st = $conn->prepare("INSERT INTO farm_settings (name, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)");
    $st->bind_param("ss", $name, $value);
    $st->execute();
}

function weather_location($conn) {
    return [
        'place' => farm_setting($conn, 'place', 'Nairobi'),
        'lat'   => (float) farm_setting($conn, 'lat', -1.2921),
        'lon'   => (float) farm_setting($conn, 'lon', 36.8219),
    ];
}

function weather_http($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 5,
                                CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_FOLLOWLOCATION => true]);
        $r = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($r !== false && $code === 200) return $r;
    }
    $ctx = stream_context_create(['http' => ['timeout' => 5]]);
    $r = @file_get_contents($url, false, $ctx);
    return $r === false ? null : $r;
}

function weather_code_text($c) {
    $m = [0 => 'Clear sky', 1 => 'Mostly clear', 2 => 'Partly cloudy', 3 => 'Overcast', 45 => 'Fog', 48 => 'Fog',
          51 => 'Light drizzle', 53 => 'Drizzle', 55 => 'Heavy drizzle', 56 => 'Freezing drizzle', 57 => 'Freezing drizzle',
          61 => 'Light rain', 63 => 'Rain', 65 => 'Heavy rain', 66 => 'Freezing rain', 67 => 'Freezing rain',
          71 => 'Light snow', 73 => 'Snow', 75 => 'Heavy snow', 77 => 'Snow grains',
          80 => 'Rain showers', 81 => 'Rain showers', 82 => 'Heavy showers', 85 => 'Snow showers', 86 => 'Snow showers',
          95 => 'Thunderstorm', 96 => 'Thunderstorm, hail', 99 => 'Thunderstorm, hail'];
    return $m[(int) $c] ?? 'Unknown';
}

// Returns current conditions + 5-day forecast, or null if nothing is available.
function weather_get($conn, $forceRefresh = false) {
    $loc = weather_location($conn);

    $st = $conn->query("SELECT payload, TIMESTAMPDIFF(MINUTE, fetched_at, NOW()) AS age FROM weather_cache WHERE id = 1");
    $row = $st ? $st->fetch_assoc() : null;
    $cached = $row ? json_decode($row['payload'], true) : null;
    $sameSpot = $cached && abs($cached['lat'] - $loc['lat']) < 0.0001 && abs($cached['lon'] - $loc['lon']) < 0.0001;

    if ($sameSpot && !$forceRefresh && (int) $row['age'] < 30) return $cached;

    // Do not hammer a failing connection: wait 5 minutes after a failure
    if (!$forceRefresh && (int) farm_setting($conn, 'weather_retry_after', 0) > time()) {
        return $sameSpot ? $cached + ['stale' => true] : null;
    }

    $url = "https://api.open-meteo.com/v1/forecast?latitude={$loc['lat']}&longitude={$loc['lon']}"
         . "&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m"
         . "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max"
         . "&timezone=auto&forecast_days=5";
    $raw = weather_http($url);
    $d = $raw ? json_decode($raw, true) : null;

    if (!$d || empty($d['current']) || empty($d['daily']['time'])) {
        farm_setting_set($conn, 'weather_retry_after', time() + 300);
        return $sameSpot ? $cached + ['stale' => true] : null;
    }

    $days = [];
    foreach ($d['daily']['time'] as $i => $date) {
        $days[] = [
            'date' => $date,
            'text' => weather_code_text($d['daily']['weather_code'][$i] ?? 0),
            'tmax' => $d['daily']['temperature_2m_max'][$i] ?? null,
            'tmin' => $d['daily']['temperature_2m_min'][$i] ?? null,
            'rain_mm' => $d['daily']['precipitation_sum'][$i] ?? 0,
            'rain_prob' => $d['daily']['precipitation_probability_max'][$i] ?? 0,
        ];
    }
    $out = [
        'place' => $loc['place'], 'lat' => $loc['lat'], 'lon' => $loc['lon'],
        'current' => [
            'temp' => $d['current']['temperature_2m'] ?? null,
            'humidity' => $d['current']['relative_humidity_2m'] ?? null,
            'rain' => $d['current']['precipitation'] ?? 0,
            'wind' => $d['current']['wind_speed_10m'] ?? null,
            'text' => weather_code_text($d['current']['weather_code'] ?? 0),
        ],
        'days' => $days,
    ];
    $json = json_encode($out);
    $up = $conn->prepare("REPLACE INTO weather_cache (id, fetched_at, payload) VALUES (1, NOW(), ?)");
    $up->bind_param("s", $json);
    $up->execute();
    farm_setting_set($conn, 'weather_retry_after', 0);
    return $out;
}

// True when meaningful rain is forecast for today (>= 60% chance or >= 2 mm) or it is raining now.
function weather_rain_expected($conn) {
    $w = weather_get($conn);
    if (!$w) return false;
    $t = $w['days'][0] ?? null;
    return ($w['current']['rain'] ?? 0) > 0.1
        || ($t && ((float) $t['rain_prob'] >= 60 || (float) $t['rain_mm'] >= 2));
}
