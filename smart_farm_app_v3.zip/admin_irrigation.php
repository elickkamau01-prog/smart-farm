<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['email']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: index.php");
    exit();
}
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function flash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
    header("Location: admin_irrigation.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        flash('error', 'Invalid request. Please try again.');
    }
    $sysId = (int) ($_POST['system_id'] ?? 0);

    if (isset($_POST['save_location'])) {
        $place = mb_substr(trim($_POST['place'] ?? ''), 0, 100);
        $lat = $_POST['lat'] ?? ''; $lon = $_POST['lon'] ?? '';
        if ($place === '' || !is_numeric($lat) || !is_numeric($lon) || abs((float) $lat) > 90 || abs((float) $lon) > 180) {
            flash('error', 'Enter a place name, latitude (-90 to 90) and longitude (-180 to 180).');
        }
        farm_setting_set($conn, 'place', $place);
        farm_setting_set($conn, 'lat', (float) $lat);
        farm_setting_set($conn, 'lon', (float) $lon);
        farm_setting_set($conn, 'weather_retry_after', 0);
        $w = weather_get($conn, true);
        flash($w ? 'success' : 'error', $w ? 'Farm location saved and weather updated.' : 'Location saved, but weather could not be loaded. Check the server\'s internet connection.');
    }

    if (isset($_POST['set_rain'])) {
        $v = isset($_POST['rain_skip']) ? 1 : 0;
        $st = $conn->prepare("UPDATE irrigation_systems SET rain_skip = ? WHERE id = ?");
        $st->bind_param("ii", $v, $sysId);
        $st->execute();
        irrigation_evaluate($conn, null, $sysId);
        flash('success', $v ? 'Watering will be postponed when rain is expected.' : 'Rain forecast will be ignored for this system.');
    }

    if (isset($_POST['add_system'])) {
        $name = trim($_POST['name'] ?? '');
        $sens = (int) ($_POST['sensor_id'] ?? 0);
        $on   = $_POST['on_below'] ?? '';
        $off  = $_POST['off_above'] ?? '';
        if ($name === '' || mb_strlen($name) > 100 || $sens <= 0 || !is_numeric($on) || !is_numeric($off)) {
            flash('error', 'Fill in the name, sensor and both limits.');
        }
        if ((float) $on >= (float) $off) {
            flash('error', '"Start below" must be lower than "Stop above".');
        }
        $key = bin2hex(random_bytes(16));
        $on = (float) $on; $off = (float) $off;
        $st = $conn->prepare("INSERT INTO irrigation_systems (name, sensor_id, on_below, off_above, api_key) VALUES (?, ?, ?, ?, ?)");
        $st->bind_param("sidds", $name, $sens, $on, $off, $key);
        $st->execute();
        irrigation_evaluate($conn, null, $conn->insert_id);
        flash('success', 'Irrigation system added.');
    }

    if (isset($_POST['set_mode'])) {
        $mode = $_POST['mode'] ?? '';
        if (!in_array($mode, ['auto', 'manual_on', 'manual_off'], true)) flash('error', 'Invalid mode.');
        $st = $conn->prepare("UPDATE irrigation_systems SET mode = ? WHERE id = ?");
        $st->bind_param("si", $mode, $sysId);
        $st->execute();
        irrigation_evaluate($conn, null, $sysId);
        flash('success', 'Mode updated.');
    }

    if (isset($_POST['regen_key'])) {
        $key = bin2hex(random_bytes(16));
        $st = $conn->prepare("UPDATE irrigation_systems SET api_key = ? WHERE id = ?");
        $st->bind_param("si", $key, $sysId);
        $st->execute();
        flash('success', 'New key generated. Update your pump controller.');
    }

    if (isset($_POST['delete_system'])) {
        $st = $conn->prepare("DELETE FROM irrigation_systems WHERE id = ?");
        $st->bind_param("i", $sysId);
        $st->execute();
        flash('success', 'Irrigation system deleted.');
    }
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$sensorOpts = $conn->query("SELECT id, name, unit FROM sensors WHERE type = 'soil_moisture' ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$systems = $conn->query("SELECT i.*, s.name AS sensor_name, s.unit,
    (SELECT r.`value` FROM readings r WHERE r.sensor_id = s.id ORDER BY r.recorded_at DESC, r.id DESC LIMIT 1) AS latest,
    (SELECT COUNT(*) FROM irrigation_events e WHERE e.system_id = i.id AND e.started_at >= NOW() - INTERVAL 7 DAY) AS runs7,
    (SELECT COALESCE(SUM(TIMESTAMPDIFF(MINUTE, e.started_at, COALESCE(e.ended_at, NOW()))), 0) FROM irrigation_events e WHERE e.system_id = i.id AND e.started_at >= NOW() - INTERVAL 7 DAY) AS mins7
    FROM irrigation_systems i JOIN sensors s ON s.id = i.sensor_id ORDER BY i.id DESC")->fetch_all(MYSQLI_ASSOC);
$events = $conn->query("SELECT i.name, e.trigger_type, e.started_at, e.ended_at,
    TIMESTAMPDIFF(MINUTE, e.started_at, COALESCE(e.ended_at, NOW())) AS mins
    FROM irrigation_events e JOIN irrigation_systems i ON i.id = e.system_id ORDER BY e.id DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

$loc = weather_location($conn);
$wx = weather_get($conn);
$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$base = rtrim(APP_URL, '/');
$modes = ['auto' => 'Auto', 'manual_on' => 'Force ON', 'manual_off' => 'Force OFF'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Irrigation control</title>
<link rel="stylesheet" href="dashboard.css">
<link rel="stylesheet" href="admin.css">
</head>
<body>
<header class="topbar">
  <div class="brand">Admin Panel</div>
  <div class="topbar-right">
    <span class="avatar"><?= $h(strtoupper(mb_substr($_SESSION['name'], 0, 1))) ?></span>
    <span class="topbar-name"><?= $h($_SESSION['name']) ?></span>
    <a class="btn-link" href="logout.php">Logout</a>
  </div>
</header>

<div class="layout">
  <nav class="sidebar">
    <a href="admin_page.php#overview" class="tab-link">Overview</a>
    <a href="admin_page.php#users" class="tab-link">Manage users</a>
    <a href="admin_sensors.php" class="tab-link">Sensors &amp; data</a>
    <a href="admin_irrigation.php" class="tab-link active">Irrigation</a>
    <a href="farm_dashboard.php" class="tab-link">Live farm dashboard</a>
    <a href="user_page.php" class="tab-link admin-link">My account</a>
  </nav>

  <main class="content">
    <?php if ($flash): ?><div class="alert <?= $h($flash['type']) ?>"><?= $h($flash['msg']) ?></div><?php endif; ?>

    <h1>Irrigation control</h1>
    <p class="muted">In Auto mode the pump starts when soil moisture drops below your lower limit and stops above the upper limit. Use Force ON / OFF to override it at any time.</p>

    <div class="box wide">
      <h3>Farm location &amp; weather</h3>
      <?php if ($wx): $t = $wx['days'][0]; ?>
        <p class="muted-inline" style="margin-bottom:12px">
          Now in <strong><?= $h($wx['place']) ?></strong>: <strong><?= $h(round($wx['current']['temp'])) ?>&deg;C</strong>, <?= $h($wx['current']['text']) ?>.
          Today: <?= (int) $t['rain_prob'] ?>% chance of rain (<?= $h($t['rain_mm']) ?> mm).
          <?= weather_rain_expected($conn) ? '<strong>Rain is expected, so automatic watering will be postponed.</strong>' : 'No significant rain expected.' ?>
        </p>
      <?php else: ?>
        <p class="muted-inline" style="margin-bottom:12px">Weather could not be loaded. The server needs internet access to reach open-meteo.com.</p>
      <?php endif; ?>
      <form method="post" class="form-grid">
        <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
        <label>Place name<input type="text" name="place" value="<?= $h($loc['place']) ?>" maxlength="100" required></label>
        <label>Latitude<input type="number" step="any" name="lat" value="<?= $h($loc['lat']) ?>" required></label>
        <label>Longitude<input type="number" step="any" name="lon" value="<?= $h($loc['lon']) ?>" required></label>
        <div class="form-actions"><button type="submit" name="save_location">Save &amp; refresh weather</button></div>
      </form>
    </div>

    <div class="box wide">
      <h3>Add an irrigation system</h3>
      <?php if (!$sensorOpts): ?>
        <p class="muted-inline">You need a soil moisture sensor first. <a href="admin_sensors.php">Add one here</a>.</p>
      <?php else: ?>
      <form method="post" class="form-grid">
        <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
        <label>Name<input type="text" name="name" placeholder="e.g. Plot A pump" maxlength="100" required></label>
        <label>Soil moisture sensor
          <select name="sensor_id"><?php foreach ($sensorOpts as $o): ?><option value="<?= (int) $o['id'] ?>"><?= $h($o['name']) ?></option><?php endforeach; ?></select>
        </label>
        <label>Start watering below<input type="number" step="any" name="on_below" placeholder="e.g. 30" required></label>
        <label>Stop watering above<input type="number" step="any" name="off_above" placeholder="e.g. 55" required></label>
        <div class="form-actions"><button type="submit" name="add_system">Add system</button></div>
      </form>
      <?php endif; ?>
    </div>

    <?php foreach ($systems as $s): $on = $s['state'] === 'on'; ?>
    <div class="box wide">
      <div class="sys-head">
        <div>
          <h3 style="margin:0"><?= $h($s['name']) ?></h3>
          <span class="muted-inline">Sensor: <?= $h($s['sensor_name']) ?> &middot; latest <?= $s['latest'] === null ? '—' : $h(round((float) $s['latest'], 2)) . ' ' . $h($s['unit']) ?> &middot; start below <?= $h($s['on_below']) ?>, stop above <?= $h($s['off_above']) ?></span>
        </div>
        <span class="badge <?= $on ? 'admin' : 'user' ?>"><?= $on ? 'Pump ON' : 'Pump OFF' ?></span>
      </div>

      <form method="post" class="modes">
        <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
        <input type="hidden" name="system_id" value="<?= (int) $s['id'] ?>">
        <input type="hidden" name="set_mode" value="1">
        <?php foreach ($modes as $k => $lab): ?>
          <button type="submit" name="mode" value="<?= $h($k) ?>" class="<?= $s['mode'] === $k ? 'active' : '' ?>"><?= $h($lab) ?></button>
        <?php endforeach; ?>
      </form>

      <form method="post" style="margin-top:14px">
        <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
        <input type="hidden" name="system_id" value="<?= (int) $s['id'] ?>">
        <input type="hidden" name="set_rain" value="1">
        <label style="margin:0;display:flex;gap:8px;align-items:center;color:var(--text)">
          <input type="checkbox" name="rain_skip" value="1" style="width:auto;margin:0" <?= (int) ($s['rain_skip'] ?? 1) ? 'checked' : '' ?> onchange="this.form.submit()">
          Postpone automatic watering when rain is expected
        </label>
      </form>

      <p class="muted-inline" style="margin:12px 0">Last 7 days: <strong><?= (int) $s['runs7'] ?></strong> runs, <strong><?= (int) $s['mins7'] ?></strong> minutes of watering.</p>

      <details><summary>Pump controller setup</summary>
        <p class="muted-inline" style="margin:8px 0">Your device asks the server what to do:</p>
<pre class="code">curl "<?= $h($base) ?>/api_irrigation.php?api_key=<?= $h($s['api_key']) ?>"
# -> {"state":"on","mode":"auto"}</pre>
      </details>

      <div style="margin-top:12px">
        <form method="post" class="inline" onsubmit="return confirm('Generate a new key? The old one stops working.')">
          <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>"><input type="hidden" name="system_id" value="<?= (int) $s['id'] ?>">
          <button type="submit" name="regen_key" class="btn-small link">New key</button>
        </form>
        <form method="post" class="inline" onsubmit="return confirm('Delete this irrigation system?')">
          <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>"><input type="hidden" name="system_id" value="<?= (int) $s['id'] ?>">
          <button type="submit" name="delete_system" class="btn-small danger">Delete</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>

    <div class="box wide scroll">
      <h3>Recent watering</h3>
      <?php if (!$events): ?><p class="muted-inline">No watering has happened yet.</p><?php else: ?>
      <table class="table">
        <thead><tr><th>System</th><th>Started</th><th>Duration</th><th>Triggered by</th></tr></thead>
        <tbody>
        <?php foreach ($events as $e): ?>
          <tr>
            <td><?= $h($e['name']) ?></td>
            <td><?= $h(date('M j, H:i', strtotime($e['started_at']))) ?></td>
            <td><?= (int) $e['mins'] ?> min<?= $e['ended_at'] === null ? ' (running)' : '' ?></td>
            <td><span class="badge <?= $e['trigger_type'] === 'auto' ? 'user' : 'admin' ?>"><?= $h($e['trigger_type']) ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </main>
</div>
</body>
</html>
