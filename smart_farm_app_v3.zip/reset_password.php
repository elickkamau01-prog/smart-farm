<?php
session_start();
require_once 'config.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$token = preg_match('/^[a-f0-9]{64}$/', $token) ? $token : '';
$error = '';

// Look up a valid, unexpired token
$resetRow = null;
if ($token !== '') {
    $hash = hash('sha256', $token);
    $stmt = $conn->prepare("SELECT id, user_id FROM password_resets WHERE token_hash = ? AND expires_at > NOW()");
    $stmt->bind_param("s", $hash);
    $stmt->execute();
    $resetRow = $stmt->get_result()->fetch_assoc();
}

if ($resetRow && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        $error = "Invalid request. Please try again.";
    } elseif (strlen($new) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($new !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $newHash = password_hash($new, PASSWORD_DEFAULT);
        $uid = (int) $resetRow['user_id'];

        $upd = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->bind_param("si", $newHash, $uid);
        $upd->execute();

        $del = $conn->prepare("DELETE FROM password_resets WHERE user_id = ?");
        $del->bind_param("i", $uid);
        $del->execute();

        session_regenerate_id(true);
        $_SESSION['login_success'] = "Password updated. You can now log in.";
        $_SESSION['active_form'] = "login-form";
        header("Location: index.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reset password</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <div class="form-box active">
  <?php if (!$resetRow): ?>
    <h2>Link not valid</h2>
    <p>This reset link is invalid or has expired.</p><br>
    <p><a href="forgot_password.php">Request a new link</a> &middot; <a href="index.php">Back to login</a></p>
  <?php else: ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
      <input type="hidden" name="token" value="<?= $h($token) ?>">
      <h2>Choose a new password</h2>
      <?php if ($error): ?><p class="error-message"><?= $h($error) ?></p><?php endif; ?>
      <input type="password" name="new_password" placeholder="New password (min 8 characters)" minlength="8" required autocomplete="new-password">
      <input type="password" name="confirm_password" placeholder="Confirm new password" minlength="8" required autocomplete="new-password">
      <button type="submit">Update password</button>
    </form>
  <?php endif; ?>
  </div>
</div>
</body>
</html>
