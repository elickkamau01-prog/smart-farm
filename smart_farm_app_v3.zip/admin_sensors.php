<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['email']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: index.php");
    exit();
}
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function flash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
    header("Location: admin_sensors.php");
    exit();
}
function numOrNull($v) {
    $v = trim((string) $v);
    return ($v !== '' && is_numeric($v)) ? (float) $v : null;
}

// ---------- Actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        flash('error', 'Invalid request. Please try again.');
    }

    // Add sensor
    if (isset($_POST['add_sensor'])) {
        $name = trim($_POST['name'] ?? '');
        $type = $_POST['type'] ?? 'other';
        if ($name === '' || mb_strlen($name) > 100 || !isset(SENSOR_TYPES[$type])) {
            flash('error', 'Enter a sensor name and choose a valid type.');
        }
        $loc  = mb_substr(trim($_POST['location'] ?? ''), 0, 100);
        $unit = mb_substr(trim($_POST['unit'] ?? ''), 0, 20);
        if ($unit === '') $unit = SENSOR_TYPES[$type][1];
        $min = numOrNull($_POST['min_value'] ?? '');
        $max = numOrNull($_POST['max_value'] ?? '');
        if ($min !== null && $max !== null && $min > $max) {
            flash('error', 'Minimum cannot be greater than maximum.');
        }
        $key = bin2hex(random_bytes(16));
        $st = $conn->prepare("INSERT INTO sensors (name, type, location, unit, min_value, max_value, api_key) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $st->bind_param("ssssdds", $name, $type, $loc, $unit, $min, $max, $key);
        $st->execute();
        flash('success', "Sensor \"$name\" added. Its API key is in the table below.");
    }

    // Add a reading by hand
    if (isset($_POST['add_reading'])) {
        $sid = (int) ($_POST['sensor_id'] ?? 0);
        $val = numOrNull($_POST['value'] ?? '');
        if ($sid <= 0 || $val === null || abs($val) > 1000000) {
            flash('error', 'Enter a valid number for the reading.');
        }
        $st = $conn->prepare("INSERT INTO readings (sensor_id, `value`, source) VALUES (?, ?, 'manual')");
        $st->bind_param("id", $sid, $val);
        $st->execute();
        irrigation_evaluate($conn, $sid);
        flash('success', 'Reading saved. Users will see it within a few seconds.');
    }

    // Delete sensor (readings are removed with it)
    if (isset($_POST['delete_sensor'])) {
        $sid = (int) ($_POST['sensor_id'] ?? 0);
        $st = $conn->prepare("DELETE FROM sensors WHERE id = ?");
        $st->bind_param("i", $sid);
        $st->execute();
        flash('success', 'Sensor and its readings deleted.');
    }

    // New API key
    if (isset($_POST['regen_key'])) {
        $sid = (int) ($_POST['sensor_id'] ?? 0);
        $key = bin2hex(random_bytes(16));
        $st = $conn->prepare("UPDATE sensors SET api_key = ? WHERE id = ?");
        $st->bind_param("si", $key, $sid);
        $st->execute();
        flash('success', 'New API key generated. Update your device with it.');
    }

    // Demo data
    if (isset($_POST['demo_data'])) {
        $demo = [
            ['Soil moisture (Plot A)', 'soil_moisture', 'Plot A', 30, 60, 45, 12],
            ['Temperature (Plot A)',   'temperature',   'Plot A', 15, 32, 24, 5],
            ['Humidity (Greenhouse)',  'humidity',      'Greenhouse', 40, 80, 60, 15],
        ];
        foreach ($demo as [$n, $t, $l, $mn, $mx, $mid, $spread]) {
            $key = bin2hex(random_bytes(16));
            $u = SENSOR_TYPES[$t][1];
            $st = $conn->prepare("INSERT INTO sensors (name, type, location, unit, min_value, max_value, api_key) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $st->bind_param("ssssdds", $n, $t, $l, $u, $mn, $mx, $key);
            $st->execute();
            $sid = $conn->insert_id;
            $demoSensor = ($t === 'soil_moisture') ? $sid : ($demoSensor ?? null);
            $ins = $conn->prepare("INSERT INTO readings (sensor_id, `value`, source, recorded_at) VALUES (?, ?, 'demo', DATE_SUB(NOW(), INTERVAL ? MINUTE))");
            for ($i = 40; $i >= 0; $i--) {
                $v = round($mid + sin($i / 5) * $spread / 2 + mt_rand(-100, 100) / 100 * $spread / 4, 1);
                $ins->bind_param("idi", $sid, $v, $i);
                $ins->execute();
            }
        }
        if (!empty($demoSensor)) {
            $ikey = bin2hex(random_bytes(16));
            $isys = $conn->prepare("INSERT INTO irrigation_systems (name, sensor_id, on_below, off_above, api_key) VALUES ('Plot A irrigation', ?, 30, 55, ?)");
            $isys->bind_param("is", $demoSensor, $ikey);
            $isys->execute();
            irrigation_evaluate($conn, $demoSensor);
        }
        flash('success', 'Demo sensors, readings and an irrigation system created.');
    }
}

// ---------- View data ----------
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$sensors = $conn->query("SELECT s.*,
    (SELECT r.`value` FROM readings r WHERE r.sensor_id = s.id ORDER BY r.recorded_at DESC, r.id DESC LIMIT 1) AS latest,
    (SELECT TIMESTAMPDIFF(MINUTE, r.recorded_at, NOW()) FROM readings r WHERE r.sensor_id = s.id ORDER BY r.recorded_at DESC, r.id DESC LIMIT 1) AS age_min,
    (SELECT COUNT(*) FROM readings r WHERE r.sensor_id = s.id) AS total
    FROM sensors s ORDER BY s.id DESC")->fetch_all(MYSQLI_ASSOC);

$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$base = rtrim(APP_URL, '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sensors &amp; farm data</title>
<link rel="stylesheet" href="dashboard.css">
<link rel="stylesheet" href="admin.css">
</head>
<body>

<header class="topbar">
  <div class="brand">Admin Panel</div>
  <div class="topbar-right">
    <span class="avatar"><?= $h(strtoupper(mb_substr($_SESSION['name'], 0, 1))) ?></span>
    <span class="topbar-name"><?= $h($_SESSION['name']) ?></span>
    <a class="btn-link" href="logout.php">Logout</a>
  </div>
</header>

<div class="layout">
  <nav class="sidebar">
    <a href="admin_page.php#overview" class="tab-link">Overview</a>
    <a href="admin_page.php#users" class="tab-link">Manage users</a>
    <a href="admin_sensors.php" class="tab-link active">Sensors &amp; data</a>
    <a href="admin_irrigation.php" class="tab-link">Irrigation</a>
    <a href="farm_dashboard.php" class="tab-link">Live farm dashboard</a>
    <a href="user_page.php" class="tab-link admin-link">My account</a>
  </nav>

  <main class="content">
    <?php if ($flash): ?>
      <div class="alert <?= $h($flash['type']) ?>"><?= $h($flash['msg']) ?></div>
    <?php endif; ?>

    <h1>Sensors &amp; farm data</h1>
    <p class="muted">Add sensors, enter readings, or let your devices send data automatically. Everything you add appears on the live dashboard that users see.</p>

    <div class="box wide">
      <h3>Add a sensor</h3>
      <form method="post" class="form-grid">
        <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
        <label>Name<input type="text" name="name" placeholder="e.g. Soil moisture (Plot A)" maxlength="100" required></label>
        <label>Type
          <select name="type" id="typeSel">
            <?php foreach (SENSOR_TYPES as $k => [$lab, $u]): ?>
              <option value="<?= $h($k) ?>" data-unit="<?= $h($u) ?>"><?= $h($lab) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Location<input type="text" name="location" placeholder="e.g. Plot A" maxlength="100"></label>
        <label>Unit<input type="text" name="unit" id="unitInp" maxlength="20" placeholder="%"></label>
        <label>Alert below<input type="number" step="any" name="min_value" placeholder="e.g. 30"></label>
        <label>Alert above<input type="number" step="any" name="max_value" placeholder="e.g. 60"></label>
        <div class="form-actions"><button type="submit" name="add_sensor">Add sensor</button></div>
      </form>
    </div>

    <div class="box wide scroll">
      <h3>Your sensors</h3>
      <?php if (!$sensors): ?>
        <p class="muted-inline">No sensors yet. Add one above, or load sample data to try the dashboard.</p>
        <form method="post" style="margin-top:12px">
          <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
          <button type="submit" name="demo_data" class="btn-small">Load demo data</button>
        </form>
      <?php else: ?>
      <table class="table">
        <thead><tr><th>Sensor</th><th>Location</th><th>Latest</th><th>Alert range</th><th>Add reading</th><th>Device key</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($sensors as $s): ?>
          <tr>
            <td><?= $h($s['name']) ?><br><span class="muted-inline"><?= $h(SENSOR_TYPES[$s['type']][0] ?? $s['type']) ?> &middot; <?= (int) $s['total'] ?> readings</span></td>
            <td><?= $h($s['location'] ?: '—') ?></td>
            <td>
              <?php if ($s['latest'] === null): ?><span class="muted-inline">none yet</span>
              <?php else: ?><strong><?= $h(round((float) $s['latest'], 2)) ?> <?= $h($s['unit']) ?></strong><br>
                <span class="muted-inline"><?= (int) $s['age_min'] ?> min ago</span><?php endif; ?>
            </td>
            <td><?= $s['min_value'] !== null ? $h($s['min_value']) : '—' ?> to <?= $s['max_value'] !== null ? $h($s['max_value']) : '—' ?></td>
            <td>
              <form method="post" class="inline">
                <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
                <input type="hidden" name="sensor_id" value="<?= (int) $s['id'] ?>">
                <input type="number" step="any" name="value" class="mini" placeholder="value" required>
                <button type="submit" name="add_reading" class="btn-small">Save</button>
              </form>
            </td>
            <td>
              <details><summary>Show key</summary><code><?= $h($s['api_key']) ?></code></details>
              <form method="post" class="inline" onsubmit="return confirm('Generate a new key? The old one stops working.')">
                <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
                <input type="hidden" name="sensor_id" value="<?= (int) $s['id'] ?>">
                <button type="submit" name="regen_key" class="btn-small link">New key</button>
              </form>
            </td>
            <td>
              <form method="post" class="inline" onsubmit="return confirm('Delete this sensor and all its readings?')">
                <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
                <input type="hidden" name="sensor_id" value="<?= (int) $s['id'] ?>">
                <button type="submit" name="delete_sensor" class="btn-small danger">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <p style="margin-top:14px"><a class="csv" href="export_readings.php">Download all readings (CSV)</a></p>
      <?php endif; ?>
    </div>

    <div class="box wide">
      <h3>Send data from a real device</h3>
      <p class="muted-inline" style="margin-bottom:10px">An ESP32, Arduino with Wi-Fi, or any script can post a reading using the sensor's key:</p>
<pre class="code">curl -X POST <?= $h($base) ?>/api_ingest.php \
  -d "api_key=YOUR_SENSOR_KEY" -d "value=42.5"</pre>
      <p class="muted-inline" style="margin-top:10px">The dashboard refreshes every 5 seconds, so new readings show up almost immediately.</p>
    </div>
  </main>
</div>

<script>
  var sel = document.getElementById('typeSel'), unit = document.getElementById('unitInp');
  function setUnit() { unit.placeholder = sel.options[sel.selectedIndex].dataset.unit || 'unit'; }
  sel.addEventListener('change', setUnit); setUnit();
</script>
</body>
</html>
