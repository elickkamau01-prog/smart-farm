<?php
session_start();
require_once 'config.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$message = '';
$error   = '';
$devLink = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        $error = "Invalid request. Please try again.";
    } elseif (time() - ($_SESSION['last_reset_request'] ?? 0) < 30) {
        $error = "Please wait a few seconds before trying again.";
    } else {
        $_SESSION['last_reset_request'] = time();
        $email = trim($_POST['email'] ?? '');

        // Same message whether or not the email exists (prevents account probing)
        $message = "If that email is registered, a reset link has been sent. It expires in 1 hour.";

        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();

            if ($row) {
                $uid = (int) $row['id'];

                $del = $conn->prepare("DELETE FROM password_resets WHERE user_id = ?");
                $del->bind_param("i", $uid);
                $del->execute();

                $token = bin2hex(random_bytes(32));
                $hash  = hash('sha256', $token);
                $ins = $conn->prepare("INSERT INTO password_resets (user_id, token_hash, expires_at)
                                       VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
                $ins->bind_param("is", $uid, $hash);
                $ins->execute();

                $link = rtrim(APP_URL, '/') . "/reset_password.php?token=" . $token;

                if (DEV_SHOW_RESET_LINK) {
                    $devLink = $link;
                } else {
                    $body = "We received a request to reset your password.\n\n"
                          . "Open this link within 1 hour:\n$link\n\n"
                          . "If you did not ask for this, ignore this email.";
                    @mail($email, "Reset your password", $body, "From: " . MAIL_FROM);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot password</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <div class="form-box active">
    <form method="post">
      <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
      <h2>Forgot password</h2>
      <p>Enter your account email and we will send you a link to choose a new password.</p><br>
      <?php if ($error): ?><p class="error-message"><?= $h($error) ?></p><?php endif; ?>
      <?php if ($message): ?><p class="success-message"><?= $h($message) ?></p><?php endif; ?>
      <?php if ($devLink): ?>
        <p class="success-message"><strong>Test mode:</strong> no email is sent. Use this link:<br>
        <a href="<?= $h($devLink) ?>"><?= $h($devLink) ?></a></p>
      <?php endif; ?>
      <input type="email" name="email" placeholder="Email" required>
      <button type="submit">Send reset link</button>
      <p><a href="index.php">Back to login</a></p>
    </form>
  </div>
</div>
</body>
</html>
