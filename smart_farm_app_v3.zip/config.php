<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "user_db";

// Public address of this app (used to build password-reset links).
const APP_URL = "http://localhost/login_app";

// While testing locally (no mail server), the reset link is shown on screen
// instead of emailed. Set to false on a real server with working mail.
const DEV_SHOW_RESET_LINK = true;
const MAIL_FROM = "no-reply@localhost";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Table for password-reset tokens (created automatically if missing)
$conn->query("CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (token_hash),
    INDEX (user_id)
)");

// Smart-farming tables (created automatically if missing)
$conn->query("CREATE TABLE IF NOT EXISTS sensors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(30) NOT NULL,
    location VARCHAR(100) NOT NULL DEFAULT '',
    unit VARCHAR(20) NOT NULL DEFAULT '',
    min_value DOUBLE NULL,
    max_value DOUBLE NULL,
    api_key CHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");

$conn->query("CREATE TABLE IF NOT EXISTS readings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sensor_id INT NOT NULL,
    `value` DOUBLE NOT NULL,
    source ENUM('manual','device','demo') NOT NULL DEFAULT 'manual',
    recorded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (sensor_id, recorded_at),
    FOREIGN KEY (sensor_id) REFERENCES sensors(id) ON DELETE CASCADE
) ENGINE=InnoDB");

// Sensor types: key => [label, default unit]
const SENSOR_TYPES = [
    'soil_moisture' => ['Soil moisture', '%'],
    'temperature'   => ['Temperature', '°C'],
    'humidity'      => ['Humidity', '%'],
    'soil_ph'       => ['Soil pH', 'pH'],
    'rainfall'      => ['Rainfall', 'mm'],
    'other'         => ['Other', ''],
];

$conn->query("CREATE TABLE IF NOT EXISTS irrigation_systems (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sensor_id INT NOT NULL,
    on_below DOUBLE NOT NULL,
    off_above DOUBLE NOT NULL,
    mode ENUM('auto','manual_on','manual_off') NOT NULL DEFAULT 'auto',
    state ENUM('on','off') NOT NULL DEFAULT 'off',
    api_key CHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sensor_id) REFERENCES sensors(id) ON DELETE CASCADE
) ENGINE=InnoDB");

$conn->query("CREATE TABLE IF NOT EXISTS irrigation_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    system_id INT NOT NULL,
    trigger_type ENUM('auto','manual') NOT NULL,
    started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME NULL,
    INDEX (system_id, started_at),
    FOREIGN KEY (system_id) REFERENCES irrigation_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB");

$conn->query("CREATE TABLE IF NOT EXISTS farm_settings (
    name VARCHAR(50) PRIMARY KEY,
    `value` VARCHAR(255) NOT NULL
) ENGINE=InnoDB");

$conn->query("CREATE TABLE IF NOT EXISTS weather_cache (
    id TINYINT PRIMARY KEY,
    fetched_at DATETIME NOT NULL,
    payload MEDIUMTEXT NOT NULL
) ENGINE=InnoDB");

// Upgrade older installs: per-system "postpone watering when rain is expected"
$col = $conn->query("SHOW COLUMNS FROM irrigation_systems LIKE 'rain_skip'");
if ($col && $col->num_rows === 0) {
    $conn->query("ALTER TABLE irrigation_systems ADD COLUMN rain_skip TINYINT(1) NOT NULL DEFAULT 1");
}

require_once __DIR__ . '/irrigation_lib.php';
require_once __DIR__ . '/weather_lib.php';
?>
