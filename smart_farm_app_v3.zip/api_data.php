<?php
session_start();
require_once 'config.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');

if (!isset($_SESSION['email'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Login required']);
    exit();
}

$sql = "SELECT s.id, s.name, s.type, s.location, s.unit, s.min_value, s.max_value,
        (SELECT r.`value` FROM readings r WHERE r.sensor_id = s.id ORDER BY r.recorded_at DESC, r.id DESC LIMIT 1) AS latest,
        (SELECT TIMESTAMPDIFF(SECOND, r.recorded_at, NOW()) FROM readings r WHERE r.sensor_id = s.id ORDER BY r.recorded_at DESC, r.id DESC LIMIT 1) AS age
        FROM sensors s ORDER BY s.id";
$rows = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

$hist = $conn->prepare("SELECT `value` FROM readings WHERE sensor_id = ? ORDER BY recorded_at DESC, id DESC LIMIT 30");
$out = [];
foreach ($rows as $r) {
    $latest = $r['latest'] === null ? null : (float) $r['latest'];
    $min = $r['min_value'] === null ? null : (float) $r['min_value'];
    $max = $r['max_value'] === null ? null : (float) $r['max_value'];

    if ($latest === null)                   $status = 'nodata';
    elseif ($min !== null && $latest < $min) $status = 'low';
    elseif ($max !== null && $latest > $max) $status = 'high';
    else                                     $status = 'ok';

    $sid = (int) $r['id'];
    $hist->bind_param("i", $sid);
    $hist->execute();
    $vals = array_map('floatval', array_column($hist->get_result()->fetch_all(MYSQLI_ASSOC), 'value'));

    $out[] = [
        'id' => $sid, 'name' => $r['name'], 'type' => $r['type'], 'location' => $r['location'],
        'unit' => $r['unit'], 'min' => $min, 'max' => $max, 'latest' => $latest,
        'age' => $r['age'] === null ? null : (int) $r['age'],
        'status' => $status, 'history' => array_reverse($vals),
    ];
}
$irr = $conn->query("SELECT i.id, i.name, i.state, i.mode, i.on_below, i.off_above, s.name AS sensor_name, s.unit, i.rain_skip,
        (SELECT r.`value` FROM readings r WHERE r.sensor_id = s.id ORDER BY r.recorded_at DESC, r.id DESC LIMIT 1) AS latest,
        (SELECT TIMESTAMPDIFF(SECOND, e.started_at, NOW()) FROM irrigation_events e WHERE e.system_id = i.id AND e.ended_at IS NULL ORDER BY e.id DESC LIMIT 1) AS running_for
        FROM irrigation_systems i JOIN sensors s ON s.id = i.sensor_id ORDER BY i.id")->fetch_all(MYSQLI_ASSOC);
$rainSoon = weather_rain_expected($conn);
foreach ($irr as &$x) {
    $x['on_below'] = (float) $x['on_below']; $x['off_above'] = (float) $x['off_above'];
    $x['running_for'] = $x['running_for'] === null ? null : (int) $x['running_for'];
    $x['rain_hold'] = $x['mode'] === 'auto' && $x['state'] === 'off' && (int) $x['rain_skip'] === 1
        && $x['latest'] !== null && (float) $x['latest'] < $x['on_below'] && $rainSoon;
}
unset($x);
echo json_encode(['sensors' => $out, 'irrigation' => $irr, 'weather' => weather_get($conn)]);
