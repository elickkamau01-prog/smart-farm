<?php
// Endpoint for IoT devices (ESP32/Arduino): POST api_key + value
require_once 'config.php';
header('Content-Type: application/json');

function out($code, $arr) { http_response_code($code); echo json_encode($arr); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(405, ['error' => 'Use POST']);

$in = $_POST;
if (!$in) {
    $j = json_decode(file_get_contents('php://input'), true);
    if (is_array($j)) $in = $j;
}
$key = (string) ($in['api_key'] ?? '');
$val = $in['value'] ?? null;

if (!preg_match('/^[a-f0-9]{32}$/', $key) || !is_numeric($val) || abs((float) $val) > 1000000) {
    out(400, ['error' => 'api_key and numeric value are required']);
}

$stmt = $conn->prepare("SELECT id FROM sensors WHERE api_key = ?");
$stmt->bind_param("s", $key);
$stmt->execute();
$s = $stmt->get_result()->fetch_assoc();
if (!$s) out(401, ['error' => 'Unknown api_key']);

$v = (float) $val;
$ins = $conn->prepare("INSERT INTO readings (sensor_id, `value`, source) VALUES (?, ?, 'device')");
$ins->bind_param("id", $s['id'], $v);
$ins->execute();
irrigation_evaluate($conn, (int) $s['id']);
out(200, ['ok' => true]);
