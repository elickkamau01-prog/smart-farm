<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['email']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: index.php");
    exit();
}
$safe = fn($v) => (is_string($v) && $v !== '' && strpbrk($v[0], "=+-@") !== false) ? "'" . $v : $v;

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="farm_readings_' . date('Ymd_His') . '.csv"');
$o = fopen('php://output', 'w');
fputcsv($o, ['Sensor', 'Type', 'Location', 'Value', 'Unit', 'Source', 'Recorded at']);
$res = $conn->query("SELECT s.name, s.type, s.location, r.`value`, s.unit, r.source, r.recorded_at
                     FROM readings r JOIN sensors s ON s.id = r.sensor_id ORDER BY r.recorded_at DESC");
while ($row = $res->fetch_row()) {
    fputcsv($o, array_map($safe, $row));
}
fclose($o);
