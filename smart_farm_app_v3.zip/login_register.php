<?php
session_start();
require_once 'config.php';

const MAX_ATTEMPTS = 5;      // failed logins allowed...
const LOCK_SECONDS = 300;    // ...before a 5-minute lock

function back($form) {
    $_SESSION['active_form'] = $form;
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

// ---------- CSRF check ----------
if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    $_SESSION['login_error'] = "Invalid request. Please try again.";
    back('login-form');
}

// ---------- REGISTER ----------
if (isset($_POST['register'])) {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $rawPass  = $_POST['password'] ?? '';

    if ($name === '' || mb_strlen($name) > 100) {
        $_SESSION['register_error'] = "Please enter a valid name.";
        back('register-form');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $_SESSION['register_error'] = "Please enter a valid email address.";
        back('register-form');
    }
    if (strlen($rawPass) < 8) {
        $_SESSION['register_error'] = "Password must be at least 8 characters.";
        back('register-form');
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['register_error'] = "Email already exists!";
        back('register-form');
    }

    // Everyone who self-registers is a normal user.
    // Admins are promoted from the admin dashboard.
    $password = password_hash($rawPass, PASSWORD_DEFAULT);
    $role = 'user';
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $role);
    $stmt->execute();

    back('login-form');
}

// ---------- LOGIN ----------
if (isset($_POST['login'])) {
    // Lockout after too many failed attempts
    if (($_SESSION['lock_until'] ?? 0) > time()) {
        $mins = (int) ceil(($_SESSION['lock_until'] - time()) / 60);
        $_SESSION['login_error'] = "Too many failed attempts. Try again in $mins minute(s).";
        back('login-form');
    }

    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            session_regenerate_id(true);   // prevents session fixation
            unset($_SESSION['failed_logins'], $_SESSION['lock_until']);
            $_SESSION['csrf']  = bin2hex(random_bytes(32));
            $_SESSION['name']  = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role']  = $user['role'];

            header("Location: " . ($user['role'] === 'admin' ? "admin_page.php" : "user_page.php"));
            exit();
        }
    }

    $_SESSION['failed_logins'] = ($_SESSION['failed_logins'] ?? 0) + 1;
    if ($_SESSION['failed_logins'] >= MAX_ATTEMPTS) {
        $_SESSION['lock_until'] = time() + LOCK_SECONDS;
        $_SESSION['failed_logins'] = 0;
    }
    $_SESSION['login_error'] = "Incorrect email or password";
    back('login-form');
}

header("Location: index.php");
exit();
