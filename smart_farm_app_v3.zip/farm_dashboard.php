<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}
$isAdmin = ($_SESSION['role'] ?? '') === 'admin';
$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Live farm dashboard</title>
<link rel="stylesheet" href="dashboard.css">
<link rel="stylesheet" href="farm.css">
</head>
<body>

<header class="topbar">
  <div class="brand">Smart Farm</div>
  <div class="topbar-right">
    <span class="avatar"><?= $h(strtoupper(mb_substr($_SESSION['name'], 0, 1))) ?></span>
    <span class="topbar-name"><?= $h($_SESSION['name']) ?></span>
    <a class="btn-link" href="<?= $isAdmin ? 'admin_page.php' : 'user_page.php' ?>">Back</a>
    <a class="btn-link" href="logout.php">Logout</a>
  </div>
</header>

<main class="farm">
  <div class="farm-head">
    <div>
      <h1>Live farm dashboard</h1>
      <p class="muted">Readings update automatically every 5 seconds.</p>
    </div>
    <div class="live"><span id="live" class="dot off"></span> <span id="stamp">Connecting…</span></div>
  </div>

  <div id="weather"></div>
  <div id="alerts"></div>
  <div id="grid" class="sgrid"></div>
  <h2 id="irrigTitle" class="sec" style="display:none">Irrigation</h2>
  <div id="irrig" class="sgrid"></div>
  <p id="empty" class="muted" style="display:none">
    No sensors have been set up yet.
    <?php if ($isAdmin): ?><a href="admin_sensors.php">Add a sensor</a><?php else: ?>Please check back later.<?php endif; ?>
  </p>
  <p class="credit">Weather data by <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo.com</a></p>
</main>

<script src="farm.js"></script>
</body>
</html>
