(function () {
  var tabs = ["overview", "profile", "security"];

  function show(name) {
    if (tabs.indexOf(name) === -1) name = "overview";
    document.querySelectorAll(".panel").forEach(function (p) {
      p.classList.toggle("active", p.id === name);
    });
    document.querySelectorAll(".tab-link[data-tab]").forEach(function (a) {
      a.classList.toggle("active", a.dataset.tab === name);
    });
  }

  window.addEventListener("hashchange", function () {
    show(location.hash.slice(1));
  });
  show(location.hash.slice(1));
})();
