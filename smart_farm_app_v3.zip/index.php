<?php
session_start();

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$errors = [
    'login'    => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? '',
];
$loginSuccess = $_SESSION['login_success'] ?? '';

$active_form = $_SESSION['active_form'] ?? 'login-form';

unset($_SESSION['login_error'], $_SESSION['register_error'], $_SESSION['active_form'], $_SESSION['login_success']);

function showError($error) {
    return !empty($error) ? '<p class="error-message">' . htmlspecialchars($error) . '</p>' : '';
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login page</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">

  <div class="form-box <?= isActiveForm('login-form', $active_form); ?>" id="login-form">
    <form action="login_register.php" method="post">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf']); ?>">
      <h2>Login</h2>
      <?= showError($errors['login']); ?>
      <?php if ($loginSuccess): ?><p class="success-message"><?= htmlspecialchars($loginSuccess); ?></p><?php endif; ?>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit" name="login">Login</button>
      <p><a href="forgot_password.php">Forgot password?</a></p>
      <p>Don't have an account? <a href="#" onclick="showForm('register-form'); return false;">Register</a></p>
    </form>
  </div>

  <div class="form-box <?= isActiveForm('register-form', $active_form); ?>" id="register-form">
    <form action="login_register.php" method="post">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf']); ?>">
      <h2>Register</h2>
      <?= showError($errors['register']); ?>
      <input type="text" name="name" placeholder="Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password (min 8 characters)" minlength="8" required>
      <button type="submit" name="register">Register</button>
      <p>Already have an account? <a href="#" onclick="showForm('login-form'); return false;">Login</a></p>
    </form>
  </div>

</div>
<script src="script.js"></script>
</body>
</html>
