(function () {
  var tabs = ["overview", "users"];

  function show(name) {
    if (tabs.indexOf(name) === -1) name = "overview";
    document.querySelectorAll(".panel").forEach(function (p) {
      p.classList.toggle("active", p.id === name);
    });
    document.querySelectorAll(".tab-link[data-tab]").forEach(function (a) {
      a.classList.toggle("active", a.dataset.tab === name);
    });
  }
  window.addEventListener("hashchange", function () { show(location.hash.slice(1)); });
  show(location.hash.slice(1));

})();

// Ask the admin for a new password before submitting a reset
function resetPw(form) {
  var pw = prompt("Enter a new password (at least 8 characters):");
  if (pw === null) return false;
  if (pw.length < 8) { alert("Password must be at least 8 characters."); return false; }
  form.querySelector('input[name="new_password"]').value = pw;
  return true;
}
