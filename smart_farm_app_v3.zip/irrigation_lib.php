<?php
// Irrigation control logic. Called whenever a new reading arrives or a mode changes.

function irrigation_set($conn, $systemId, $newState, $trigger) {
    $st = $conn->prepare("SELECT state FROM irrigation_systems WHERE id = ?");
    $st->bind_param("i", $systemId);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    if (!$row || $row['state'] === $newState) return;

    $up = $conn->prepare("UPDATE irrigation_systems SET state = ? WHERE id = ?");
    $up->bind_param("si", $newState, $systemId);
    $up->execute();

    if ($newState === 'on') {
        $ev = $conn->prepare("INSERT INTO irrigation_events (system_id, trigger_type) VALUES (?, ?)");
        $ev->bind_param("is", $systemId, $trigger);
        $ev->execute();
    } else {
        $ev = $conn->prepare("UPDATE irrigation_events SET ended_at = NOW() WHERE system_id = ? AND ended_at IS NULL");
        $ev->bind_param("i", $systemId);
        $ev->execute();
    }
}

// Decide pump state for the systems tied to a sensor (or one system).
function irrigation_evaluate($conn, $sensorId = null, $systemId = null) {
    if ($systemId !== null) {
        $q = $conn->prepare("SELECT * FROM irrigation_systems WHERE id = ?");
        $q->bind_param("i", $systemId);
    } elseif ($sensorId !== null) {
        $q = $conn->prepare("SELECT * FROM irrigation_systems WHERE sensor_id = ?");
        $q->bind_param("i", $sensorId);
    } else {
        $q = $conn->prepare("SELECT * FROM irrigation_systems");
    }
    $q->execute();
    $systems = $q->get_result()->fetch_all(MYSQLI_ASSOC);

    $last = $conn->prepare("SELECT `value` FROM readings WHERE sensor_id = ? ORDER BY recorded_at DESC, id DESC LIMIT 1");
    foreach ($systems as $s) {
        $sid = (int) $s['id'];
        if ($s['mode'] === 'manual_on')  { irrigation_set($conn, $sid, 'on',  'manual'); continue; }
        if ($s['mode'] === 'manual_off') { irrigation_set($conn, $sid, 'off', 'manual'); continue; }

        // Automatic: start below the lower limit, stop above the upper limit,
        // keep the current state in between (prevents rapid on/off switching).
        $sensor = (int) $s['sensor_id'];
        $last->bind_param("i", $sensor);
        $last->execute();
        $r = $last->get_result()->fetch_assoc();
        if (!$r) continue;
        $v = (float) $r['value'];
        if ($v < (float) $s['on_below']) {
            // Save water: hold off if rain is on the way (can be disabled per system)
            if ((int) ($s['rain_skip'] ?? 1) === 1 && weather_rain_expected($conn)) continue;
            irrigation_set($conn, $sid, 'on', 'auto');
        }
        elseif ($v > (float) $s['off_above'])   irrigation_set($conn, $sid, 'off', 'auto');
    }
}
