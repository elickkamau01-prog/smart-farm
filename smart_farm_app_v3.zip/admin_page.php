<?php
session_start();
require_once 'config.php';

// ---------- Access control: admins only ----------
if (!isset($_SESSION['email']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: index.php");
    exit();
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function flash($type, $msg, $tab) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg, 'tab' => $tab];
    $qs = $_SERVER['QUERY_STRING'] ?? '';
    header("Location: admin_page.php" . ($qs !== '' ? "?$qs" : "") . "#" . $tab);
    exit();
}

// ---------- Current admin ----------
$stmt = $conn->prepare("SELECT id, name, email, role FROM users WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$me = $stmt->get_result()->fetch_assoc();

if (!$me || $me['role'] !== 'admin') {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

// ---------- Actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        flash('error', 'Invalid request. Please try again.', 'overview');
    }
    $targetId = (int) ($_POST['user_id'] ?? 0);

    // Change role
    if (isset($_POST['change_role'])) {
        $newRole = ($_POST['role'] ?? '') === 'admin' ? 'admin' : 'user';
        if ($targetId === (int) $me['id']) {
            flash('error', 'You cannot change your own role.', 'users');
        }
        $upd = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
        $upd->bind_param("si", $newRole, $targetId);
        $upd->execute();
        flash('success', 'Role updated.', 'users');
    }

    // Delete user
    if (isset($_POST['delete_user'])) {
        if ($targetId === (int) $me['id']) {
            flash('error', 'You cannot delete your own account.', 'users');
        }
        $del = $conn->prepare("DELETE FROM users WHERE id = ?");
        $del->bind_param("i", $targetId);
        $del->execute();
        flash('success', 'User deleted.', 'users');
    }

    // Reset password
    if (isset($_POST['reset_password'])) {
        $new = $_POST['new_password'] ?? '';
        if (strlen($new) < 8) {
            flash('error', 'Password must be at least 8 characters.', 'users');
        }
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->bind_param("si", $hash, $targetId);
        $upd->execute();
        flash('success', 'Password reset.', 'users');
    }
}

// ---------- View data ----------
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$stats = $conn->query("
    SELECT COUNT(*) AS total,
           SUM(role = 'admin') AS admins,
           SUM(role = 'user') AS users,
           SUM(created_at >= (NOW() - INTERVAL 7 DAY)) AS new_week
    FROM users
")->fetch_assoc();

// Recent sign-ups (overview)
$recent = $conn->query("SELECT name, email, role, created_at FROM users ORDER BY id DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

// Paginated + searchable user list
$perPage = 10;
$q       = trim($_GET['q'] ?? '');
$like    = '%' . $q . '%';

$cnt = $conn->prepare("SELECT COUNT(*) FROM users WHERE name LIKE ? OR email LIKE ?");
$cnt->bind_param("ss", $like, $like);
$cnt->execute();
$cnt->bind_result($totalRows);
$cnt->fetch();
$cnt->close();

$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page       = min(max(1, (int) ($_GET['p'] ?? 1)), $totalPages);
$offset     = ($page - 1) * $perPage;

$lst = $conn->prepare("SELECT id, name, email, role, created_at FROM users
                       WHERE name LIKE ? OR email LIKE ?
                       ORDER BY id DESC LIMIT ? OFFSET ?");
$lst->bind_param("ssii", $like, $like, $perPage, $offset);
$lst->execute();
$allUsers = $lst->get_result()->fetch_all(MYSQLI_ASSOC);

$pageUrl = fn($p) => 'admin_page.php?' . http_build_query(array_filter(['q' => $q, 'p' => $p > 1 ? $p : null])) . '#users';
$from = $totalRows ? $offset + 1 : 0;
$to   = $offset + count($allUsers);

$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$fmt = fn($d) => $d ? date('M j, Y', strtotime($d)) : '—';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="dashboard.css">
<link rel="stylesheet" href="admin.css">
</head>
<body>

<header class="topbar">
  <div class="brand">Admin Panel</div>
  <div class="topbar-right">
    <span class="avatar"><?= $h(strtoupper(mb_substr($me['name'], 0, 1))) ?></span>
    <span class="topbar-name"><?= $h($me['name']) ?></span>
    <a class="btn-link" href="logout.php">Logout</a>
  </div>
</header>

<div class="layout">
  <nav class="sidebar">
    <a href="#overview" class="tab-link" data-tab="overview">Overview</a>
    <a href="#users" class="tab-link" data-tab="users">Manage users</a>
    <a href="admin_sensors.php" class="tab-link">Sensors &amp; data</a>
    <a href="admin_irrigation.php" class="tab-link">Irrigation</a>
    <a href="farm_dashboard.php" class="tab-link">Live farm dashboard</a>
    <a href="user_page.php" class="tab-link admin-link">My account</a>
  </nav>

  <main class="content">

    <?php if ($flash): ?>
      <div class="alert <?= $h($flash['type']) ?>"><?= $h($flash['msg']) ?></div>
    <?php endif; ?>

    <!-- Overview -->
    <section class="panel" id="overview">
      <h1>Welcome, <?= $h($me['name']) ?></h1>
      <p class="muted">Here is how your application is doing.</p>

      <div class="cards">
        <div class="card"><span class="card-label">Total users</span><span class="card-value"><?= (int) $stats['total'] ?></span></div>
        <div class="card"><span class="card-label">Admins</span><span class="card-value"><?= (int) $stats['admins'] ?></span></div>
        <div class="card"><span class="card-label">Regular users</span><span class="card-value"><?= (int) $stats['users'] ?></span></div>
        <div class="card"><span class="card-label">New this week</span><span class="card-value"><?= (int) $stats['new_week'] ?></span></div>
      </div>

      <div class="box wide">
        <h3>Recent sign-ups</h3>
        <table class="table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
          <tbody>
          <?php foreach ($recent as $u): ?>
            <tr>
              <td><?= $h($u['name']) ?></td>
              <td><?= $h($u['email']) ?></td>
              <td><span class="badge <?= $h($u['role']) ?>"><?= $h($u['role']) ?></span></td>
              <td><?= $h($fmt($u['created_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Manage users -->
    <section class="panel" id="users">
      <h1>Manage users</h1>
      <p class="muted">Change roles, reset passwords, or remove accounts.</p>

      <form method="get" action="admin_page.php#users" class="searchbar">
        <input type="search" name="q" class="search" value="<?= $h($q) ?>" placeholder="Search by name or email…">
        <button type="submit" class="btn-small">Search</button>
        <?php if ($q !== ''): ?><a class="clear" href="admin_page.php#users">Clear</a><?php endif; ?>
      </form>

      <div class="box wide scroll">
        <table class="table" id="userTable">
          <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
          <tbody>
          <?php if (!$allUsers): ?>
            <tr><td colspan="6" class="muted-inline">No users found.</td></tr>
          <?php endif; ?>
          <?php foreach ($allUsers as $u): $isMe = ((int) $u['id'] === (int) $me['id']); ?>
            <tr>
              <td>#<?= (int) $u['id'] ?></td>
              <td><?= $h($u['name']) ?><?= $isMe ? ' <em class="muted-inline">(you)</em>' : '' ?></td>
              <td><?= $h($u['email']) ?></td>
              <td>
                <?php if ($isMe): ?>
                  <span class="badge admin">admin</span>
                <?php else: ?>
                  <form method="post" class="inline">
                    <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
                    <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                    <select name="role" onchange="this.form.submit()">
                      <option value="user"  <?= $u['role'] === 'user'  ? 'selected' : '' ?>>user</option>
                      <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>admin</option>
                    </select>
                    <input type="hidden" name="change_role" value="1">
                  </form>
                <?php endif; ?>
              </td>
              <td><?= $h($fmt($u['created_at'])) ?></td>
              <td class="actions">
                <?php if (!$isMe): ?>
                  <form method="post" class="inline" onsubmit="return resetPw(this)">
                    <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
                    <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                    <input type="hidden" name="new_password" value="">
                    <button type="submit" name="reset_password" class="btn-small">Reset password</button>
                  </form>
                  <form method="post" class="inline" onsubmit="return confirm('Delete this user permanently?')">
                    <input type="hidden" name="csrf" value="<?= $h($_SESSION['csrf']) ?>">
                    <input type="hidden" name="user_id" value="<?= (int) $u['id'] ?>">
                    <button type="submit" name="delete_user" class="btn-small danger">Delete</button>
                  </form>
                <?php else: ?>
                  <span class="muted-inline">—</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="pager">
        <span class="muted-inline">Showing <?= $from ?>–<?= $to ?> of <?= (int) $totalRows ?></span>
        <?php if ($totalPages > 1): ?>
        <div class="pages">
          <?php if ($page > 1): ?><a href="<?= $h($pageUrl($page - 1)) ?>">‹ Prev</a><?php endif; ?>
          <?php for ($i = 1; $i <= $totalPages; $i++):
                if ($i === 1 || $i === $totalPages || abs($i - $page) <= 1): ?>
            <a href="<?= $h($pageUrl($i)) ?>" class="<?= $i === $page ? 'current' : '' ?>"><?= $i ?></a>
          <?php elseif (abs($i - $page) === 2): ?><span>…</span>
          <?php endif; endfor; ?>
          <?php if ($page < $totalPages): ?><a href="<?= $h($pageUrl($page + 1)) ?>">Next ›</a><?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </section>

  </main>
</div>

<script src="admin.js"></script>
</body>
</html>
