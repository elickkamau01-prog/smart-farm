CREATE DATABASE IF NOT EXISTS user_db;
USE user_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- If you already created the table, run this once instead:
-- ALTER TABLE users ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Smart farming tables (also created automatically by config.php)
CREATE TABLE IF NOT EXISTS sensors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(30) NOT NULL,
    location VARCHAR(100) NOT NULL DEFAULT '',
    unit VARCHAR(20) NOT NULL DEFAULT '',
    min_value DOUBLE NULL,
    max_value DOUBLE NULL,
    api_key CHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS readings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sensor_id INT NOT NULL,
    `value` DOUBLE NOT NULL,
    source ENUM('manual','device','demo') NOT NULL DEFAULT 'manual',
    recorded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (sensor_id, recorded_at),
    FOREIGN KEY (sensor_id) REFERENCES sensors(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Irrigation (also created automatically by config.php)
CREATE TABLE IF NOT EXISTS irrigation_systems (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    sensor_id INT NOT NULL,
    on_below DOUBLE NOT NULL,
    off_above DOUBLE NOT NULL,
    mode ENUM('auto','manual_on','manual_off') NOT NULL DEFAULT 'auto',
    state ENUM('on','off') NOT NULL DEFAULT 'off',
    api_key CHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sensor_id) REFERENCES sensors(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS irrigation_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    system_id INT NOT NULL,
    trigger_type ENUM('auto','manual') NOT NULL,
    started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME NULL,
    INDEX (system_id, started_at),
    FOREIGN KEY (system_id) REFERENCES irrigation_systems(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Weather (also created automatically by config.php)
CREATE TABLE IF NOT EXISTS farm_settings (
    name VARCHAR(50) PRIMARY KEY,
    `value` VARCHAR(255) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS weather_cache (
    id TINYINT PRIMARY KEY,
    fetched_at DATETIME NOT NULL,
    payload MEDIUMTEXT NOT NULL
) ENGINE=InnoDB;
-- ALTER TABLE irrigation_systems ADD COLUMN rain_skip TINYINT(1) NOT NULL DEFAULT 1;
