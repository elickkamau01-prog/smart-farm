(function () {
  var grid = document.getElementById("grid");
  var alertsBox = document.getElementById("alerts");
  var stamp = document.getElementById("stamp");
  var dot = document.getElementById("live");
  var empty = document.getElementById("empty");
  var LABEL = { ok: "Normal", low: "Too low", high: "Too high", nodata: "No data" };
  var COLOR = { ok: "#1f9d55", low: "#d98c00", high: "#db4141", nodata: "#9aa3b2" };

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }
  function ago(s) {
    if (s === null) return "no readings yet";
    if (s < 5) return "just now";
    if (s < 60) return s + " s ago";
    if (s < 3600) return Math.floor(s / 60) + " min ago";
    if (s < 86400) return Math.floor(s / 3600) + " h ago";
    return Math.floor(s / 86400) + " d ago";
  }
  function fmt(n) { return Math.round(n * 100) / 100; }

  function spark(canvas, vals, color) {
    var dpr = window.devicePixelRatio || 1, w = 260, h = 60;
    canvas.width = w * dpr; canvas.height = h * dpr;
    var c = canvas.getContext("2d");
    c.scale(dpr, dpr);
    if (vals.length < 2) return;
    var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
    if (hi === lo) { hi += 1; lo -= 1; }
    c.beginPath();
    vals.forEach(function (v, i) {
      var x = 4 + (i / (vals.length - 1)) * (w - 8);
      var y = h - 6 - ((v - lo) / (hi - lo)) * (h - 12);
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    });
    c.strokeStyle = color; c.lineWidth = 2; c.lineJoin = "round"; c.stroke();
  }

  function render(data) {
    var list = data.sensors || [];
    grid.textContent = ""; alertsBox.textContent = "";
    empty.style.display = list.length ? "none" : "block";

    list.forEach(function (s) {
      if (s.status === "low" || s.status === "high") {
        var a = el("div", "alert-row " + s.status,
          s.name + (s.location ? " (" + s.location + ")" : "") + " is " +
          (s.status === "low" ? "below" : "above") + " the safe range: " + fmt(s.latest) + " " + s.unit);
        alertsBox.appendChild(a);
      }

      var card = el("div", "scard");
      var top = el("div", "scard-top");
      var title = el("div");
      title.appendChild(el("div", "scard-name", s.name));
      title.appendChild(el("div", "scard-loc", s.location || ""));
      top.appendChild(title);
      top.appendChild(el("span", "pill " + s.status, LABEL[s.status]));
      card.appendChild(top);

      var val = el("div", "scard-val");
      val.appendChild(document.createTextNode(s.latest === null ? "—" : fmt(s.latest)));
      if (s.latest !== null) val.appendChild(el("span", "scard-unit", " " + s.unit));
      card.appendChild(val);

      var cv = document.createElement("canvas");
      cv.className = "spark";
      card.appendChild(cv);
      spark(cv, s.history || [], COLOR[s.status]);

      var range = (s.min !== null || s.max !== null)
        ? "Safe range: " + (s.min !== null ? s.min : "–") + " to " + (s.max !== null ? s.max : "–") + " " + s.unit
        : "No alert range set";
      card.appendChild(el("div", "scard-foot", range));
      card.appendChild(el("div", "scard-foot", "Updated " + ago(s.age)));
      grid.appendChild(card);
    });
  }

  function renderWeather(w) {
    var box = document.getElementById("weather");
    box.textContent = "";
    if (!w) return;
    var card = el("div", "wcard");
    var now = el("div", "wnow");
    now.appendChild(el("div", "scard-loc", w.place + (w.stale ? " (offline, showing last data)" : "")));
    now.appendChild(el("div", "wtemp", Math.round(w.current.temp) + "°C"));
    now.appendChild(el("div", "scard-name", w.current.text));
    now.appendChild(el("div", "scard-foot", "Humidity " + w.current.humidity + "% · Wind " + w.current.wind + " km/h · Rain now " + w.current.rain + " mm"));
    card.appendChild(now);
    var row = el("div", "wdays");
    w.days.forEach(function (d, i) {
      var day = el("div", "wday");
      var name = i === 0 ? "Today" : new Date(d.date + "T12:00:00").toLocaleDateString(undefined, { weekday: "short" });
      day.appendChild(el("div", "scard-name", name));
      day.appendChild(el("div", "scard-foot", d.text));
      day.appendChild(el("div", "wrange", Math.round(d.tmax) + "° / " + Math.round(d.tmin) + "°"));
      day.appendChild(el("div", "wrain" + (d.rain_prob >= 60 ? " wet" : ""), d.rain_prob + "% rain · " + d.rain_mm + " mm"));
      row.appendChild(day);
    });
    card.appendChild(row);
    box.appendChild(card);
  }

  var MODE = { auto: "Automatic", manual_on: "Manual: forced ON", manual_off: "Manual: forced OFF" };
  function dur(s) { return s < 60 ? s + " s" : Math.floor(s / 60) + " min"; }
  function renderIrrig(list) {
    var box = document.getElementById("irrig");
    box.textContent = "";
    document.getElementById("irrigTitle").style.display = list.length ? "block" : "none";
    list.forEach(function (i) {
      var on = i.state === "on";
      var card = el("div", "scard");
      var top = el("div", "scard-top");
      var t = el("div");
      t.appendChild(el("div", "scard-name", i.name));
      t.appendChild(el("div", "scard-loc", MODE[i.mode] || i.mode));
      top.appendChild(t);
      top.appendChild(el("span", "pill " + (on ? "ok" : "nodata"), on ? "Running" : "Off"));
      card.appendChild(top);
      card.appendChild(el("div", "scard-val", on ? "Watering" : "Idle"));
      if (on && i.running_for !== null) card.appendChild(el("div", "scard-foot", "Running for " + dur(i.running_for)));
      if (i.rain_hold) card.appendChild(el("div", "scard-foot hold", "Watering postponed: rain is expected today"));
      card.appendChild(el("div", "scard-foot", i.mode === "auto"
        ? "Starts below " + i.on_below + " " + i.unit + ", stops above " + i.off_above + " " + i.unit + " (" + i.sensor_name + ")"
        : "Automatic control is paused by the farm manager"));
      box.appendChild(card);
    });
  }

  function load() {
    fetch("api_data.php", { credentials: "same-origin", cache: "no-store" })
      .then(function (r) {
        if (r.status === 401) { location.href = "index.php"; throw new Error("auth"); }
        return r.json();
      })
      .then(function (d) {
        render(d);
        renderIrrig(d.irrigation || []);
        renderWeather(d.weather);
        dot.classList.remove("off");
        stamp.textContent = "Live · " + new Date().toLocaleTimeString();
      })
      .catch(function () {
        dot.classList.add("off");
        stamp.textContent = "Connection lost — retrying…";
      });
  }
  load();
  setInterval(load, 5000);
})();
