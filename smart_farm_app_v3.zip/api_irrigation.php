<?php
// The pump controller (ESP32/Arduino) calls this to learn whether to run the pump.
// GET /api_irrigation.php?api_key=SYSTEM_KEY   ->  {"state":"on"|"off","mode":"auto|manual_on|manual_off"}
require_once 'config.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');

$key = (string) ($_GET['api_key'] ?? $_POST['api_key'] ?? '');
if (!preg_match('/^[a-f0-9]{32}$/', $key)) { http_response_code(400); echo json_encode(['error' => 'api_key required']); exit; }

$st = $conn->prepare("SELECT id FROM irrigation_systems WHERE api_key = ?");
$st->bind_param("s", $key);
$st->execute();
$r = $st->get_result()->fetch_assoc();
if (!$r) { http_response_code(401); echo json_encode(['error' => 'Unknown api_key']); exit; }

irrigation_evaluate($conn, null, (int) $r['id']);

$st = $conn->prepare("SELECT state, mode FROM irrigation_systems WHERE id = ?");
$st->bind_param("i", $r['id']);
$st->execute();
echo json_encode($st->get_result()->fetch_assoc());
